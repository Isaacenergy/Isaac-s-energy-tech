ISAAC'S ENERGY TECH LTD WEBSITE

Files:
- index.html       Main website page
- styles.css       Website design and responsive layout
- script.js        Mobile menu, year and WhatsApp enquiry form
- assets/logo.jpg  Your uploaded company logo

CONTACT DETAILS CONFIGURED:
WhatsApp: 0767 145 643
Direct calls: 0767 145 643 / 0705 434 135

To view:
1. Extract the ZIP.
2. Open index.html in a browser.
3. For VS Code, open the extracted folder and open index.html.

CONTACT / LOCATION:
Location: Gayaza Road, Kumbuzi, Uganda
WhatsApp: 0767 145 643
Direct calls: 0767 145 643 / 0705 434 135

ADDED:
The latest customer/product photos are included in the website gallery.
