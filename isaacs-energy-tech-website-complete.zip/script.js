// ISAAC'S ENERGY TECH LTD website
// Replace the number below with your business WhatsApp number in international format.
// Example for Uganda: 2567XXXXXXXX (do not include +, spaces or leading 0).
const WHATSAPP_NUMBER = "256767145643";

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
menuToggle.addEventListener("click", () => navLinks.classList.toggle("open"));

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

document.getElementById("year").textContent = new Date().getFullYear();

function sendEnquiry(event) {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const service = document.getElementById("service").value;
  const message = document.getElementById("message").value.trim();

  const text = `Hello ISAAC'S ENERGY TECH LTD,%0A%0AMy name is ${encodeURIComponent(name)}.%0APhone/WhatsApp: ${encodeURIComponent(phone)}%0AService needed: ${encodeURIComponent(service)}%0AMessage: ${encodeURIComponent(message)}%0A%0AI would like to get a quotation.`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, "_blank");
}
